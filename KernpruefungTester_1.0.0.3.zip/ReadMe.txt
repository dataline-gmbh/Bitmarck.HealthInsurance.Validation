Installation des Testers:

1. Folgende Dateien in ein Verzeichnis kopieren:

   KernpruefungAAG_<version>-bin.jar
   Inhalt von KernpruefungTester_<version>.zip (entpacken)
	
2. Datei tester.bat anpassen. 
	 
   Dort die Variable JAVA_HOME setzen, z.B.
	 set JAVA_HOME=C:\Programme\Java\jre1.6.0_03.
	 
3. Aufruf von tester.bat.